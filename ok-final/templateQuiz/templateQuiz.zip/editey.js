//<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
//http://www.w3schools.com/jsref/event_onchange.asp
 //replace();
//222

function replace()
{
//alert("KKKK");  
//	alert( document.body.innerHTML );  

var x="Y";
var t=mChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[Y\]/g, t);
var x="N";
var t=mChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[N\]/g, t);
	
//------------------------------------------------------------------
var x="A";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[A\]/g, t);
var x="B";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[B\]/g, t);
var x="C";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[C\]/g, t);
var x="D";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[D\]/g, t);
var x="E";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[E\]/g, t);
var x="F";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[F\]/g, t);
var x="G";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[G\]/g, t);
var x="0";
var t=cChoice(x);
document.body.innerHTML = document.body.innerHTML.replace(/\[0\]/g, t);

//------------------------------------------------------------------

//alert("replace");
var str= document.body.innerHTML.match(/\[\[.*?\]\]/g);
//alert(str);
if (str!=null)
{
for (i=0;i < str.length;i++)
{
var t=fChoice(x,str[i]);
document.body.innerHTML = document.body.innerHTML.replace(str[i], t);
}
}

/*    var str = "fwerwerew [[fddfdsf]]  [[fddfdsf]]  [[fddfdsf]] fsdfdfsdfsdf dfssssssss fds [[llll]] rewrwerewrewr"; 
    
    var result = str.match(/\[\[.{1,23}\]\]/g);

    document.getElementById("demo").innerHTML = result;
*/





//------------------------------------------------------------------

//document.body.innerHTML = document.body.innerHTML.replace(/\[\[.*\]\]/g, t);
/*
<select>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
</select>

*/




}

function fChoice(x, txt)
{
txt=txt.trim();
txt = txt.substr(2, txt.length-4); //Περιεργο substring
//style="width:150px;border-top:0;border-left:0;border-right:0;border-color:red;background:yellow">
var t="\<SELECT NAME=\"mChoice\"\> "+
"\<OPTION VALUE=\"" + txt +"\"\>_" +"\<\/option\>"+
"\<OPTION VALUE=\"" + txt+"\"\>"+txt+"\<\/option\>"+
"\<\/SELECT\>";
	
	return t;
}

function mChoice(x)
{
	
	var t="\<SELECT NAME=\"mChoice\"\> "+
"\<OPTION VALUE=\"" + x +"\"\>_" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>Y " +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>N " +"\<\/option\>"+
"\<\/SELECT\>"
	
	return t;
}

function cChoice(x)
{
	var t="\<SELECT NAME=\"cChoice\"\> "+
"\<OPTION VALUE=\"" + x +"\"\>_" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>A" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>B" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>C" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>D" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>E" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>F" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>G" +"\<\/option\>"+
"\<OPTION VALUE=\"" + x +"\"\>0" +"\<\/option\>"+
"\<\/SELECT\>"
	
	return t;
}

 
function myFunction() {
    var x = document.getElementById("mySelect").value;
    document.getElementById("demo").innerHTML = "You selected: " + x;
}

$( document ).ready(function() {
	//alert("replaceAfter");
	replace();

	
	
$('select').on('change', function() {


var txt=$("option:selected", this).text();
txt=txt.trim();
//alert(txt);
//alert(txt.length);
	if (this.value== txt) 
		{
			 $(this).css('background-color', 'C0FFA1');
		}
if (this.value!= txt) 
		{
			 $(this).css('background-color', 'FFE4E3');
		}
	if (txt=="_") 
		{
			 $(this).css('background-color', 'white');
		   
		}




})

});
